#include <iostream>
#include <cstdlib>
#include <stdlib.h>
#include <time.h>
using namespace std;

void test(int a[],int &num_di_bit)
    {
        int i=0;
       
        if(a[i]==! 1){
       
        int j;
       
        while(i<num_di_bit)
        {
       
        j=i+1;
        a[i]=a[j];
        i=i+1;
       
        }
             
        }

        num_di_bit=num_di_bit-1;
       
        cout<<"\nla sequenza e': ";
       
    for(int i=0; i<num_di_bit; i++){
        cout<<a[i];
    }
    }
int num_di_bit;

int main(){

cout<<"numero di bit da generare da 8 a 32: ";
cin>>num_di_bit;

while (num_di_bit<8 || num_di_bit>32){

cout<<"numero invalido, reinserire numero: ";
cin>>num_di_bit;

}
int a[num_di_bit];
srand (time(NULL));
cout<<"  numero di bit: "<<num_di_bit<<endl;
for(int i=0; i<num_di_bit; i++){
a[i]=rand() %2;
}

cout<<"la sequenza e': ";

for(int i=0; i<num_di_bit; i++){
cout<<a[i];
}

cout<<"\n\nMx: ";
for(int i=0, j=num_di_bit; i<num_di_bit, j>=0; i++, j--) {
if (a[i]==1)
cout<<"x^"<<j-1<<"+";
}
num_di_bit=num_di_bit+3;

a[num_di_bit];
a[num_di_bit-1]=0;
a[num_di_bit-2]=0;
a[num_di_bit-3]=0;



char scelta;
cout<<"\npremi (a) se vuoi che il divisore sia 1011 \npremi (b) se vuoi che il divisore sia 10011 ";
cin>>scelta;
int n;
int Gx[n];

if(scelta='a'){

n=4;
Gx[n];

Gx[0]=1;
Gx[1]=1;
Gx[2]=0;
Gx[3]=1;
}

if(scelta='b'){

n=5;
Gx[n];

Gx[0]=1;
Gx[1]=1;
Gx[2]=0;
Gx[3]=0;
Gx[4]=1;
}

bool inf=true;

for(int i=0, j=3 ; n=true ; i++, j--){
cout<<endl<<"il risultato tra: "<<a[i]<<" e "<<Gx[j]<<"= ";

if (j==-1){

j=j+n;

}

a[i]=a[i]^Gx[j];

cout<<a[i];

     if(num_di_bit<=4){
            cout<<"\nRISULTATO FINALE: ";
       test(a, num_di_bit);
   

       return 0;
           
        }

test(a, num_di_bit);

}

}
